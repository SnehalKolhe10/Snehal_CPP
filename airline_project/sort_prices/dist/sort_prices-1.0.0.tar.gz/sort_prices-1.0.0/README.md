# Sort Prices

A Python library to sort prices from low to high for Django or any Python application.

## Installation

```bash
pip install sort_prices
